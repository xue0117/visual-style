# Visual Style

一套可跨 AI、绘图库和输出媒介复用的数据可视化规范。核心色为：

- `#5271AE`
- `#70ACDE`
- `#F5CC7D`
- `#FFA660`
- `#D85B59`

## 普通 AI 使用方式

1. 打开 `PROMPT.md`。
2. 将全文放入 AI 的系统提示词、项目指令或自定义指令；若平台不支持长期指令，就在新对话中上传该文件。
3. 每次另行上传当次数据，并说明分析目标。
4. 对 AI 说：`完整阅读 PROMPT.md，按照其中的视觉和数据适配规则分析这份数据并绘图。`

数据不需要套用固定模板。提示词包含 CSV、Excel、JSON、粘贴表格、多层表头、宽表/长表、多文件、坐标数据、PDF和截图等适配规则。

如果 AI 能访问公开网页，也可以提供 GitHub 中 `PROMPT.md` 的 Raw 链接并要求完整读取；如果不能联网，直接上传文件或粘贴全文。

## 支持 Skill 的 AI 使用方式

安装整个目录，并调用：

```text
$visual-style
```

Skill 入口为 `SKILL.md`，详细规则位于 `references/`，机器可读主题位于 `assets/theme-tokens.json`。

Trae 请下载 `visual-style-trae.zip` 后直接导入。此压缩包的最外层就是 `SKILL.md`、`references/` 与 `assets/`，符合 Trae 的安装检查。

## 常用指令

```text
使用 $visual-style，先检查这份数据的字段、单位、缺失值和重复测量结构，再选择合适的图型并输出统一风格图表。
```

```text
完整阅读 PROMPT.md。数据格式可能不规则，请先整理但不要改变原始含义；有会影响结论的歧义再问我。
```

## 文件说明

- `PROMPT.md`：普通 AI 可直接使用的单文件提示词。
- `SKILL.md`：支持 Agent Skills 的 AI 使用的入口。
- `references/`：颜色、图型、数据适配和工具实现细则。
- `assets/theme-tokens.json`：颜色、字体、字号、线宽和透明度等机器可读变量。
- `visual-style-trae.zip`：Trae 可直接导入的完整 Skill 安装包，压缩包根目录包含 `SKILL.md`。

本项目采用 MIT License，可自由使用、复制和修改，并保留许可证及版权声明。
